-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Máquina: localhost
-- Data de Criação: 18-Mar-2024 às 17:52
-- Versão do servidor: 5.0.45
-- versão do PHP: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de Dados: `pap24`
-- 

-- --------------------------------------------------------

-- 
-- Estrutura da tabela `departamento`
-- 

CREATE TABLE `departamento` (
  `id_departamento` varchar(3) collate latin1_general_ci NOT NULL,
  `nome` varchar(20) collate latin1_general_ci NOT NULL,
  `Status` char(1) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_departamento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Extraindo dados da tabela `departamento`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `faq`
-- 

CREATE TABLE `faq` (
  `id_faq` int(9) NOT NULL auto_increment,
  `Categoria_Dep` varchar(3) collate latin1_general_ci default NULL,
  `Questao` varchar(30) collate latin1_general_ci NOT NULL,
  `Informacao` varchar(50) collate latin1_general_ci NOT NULL,
  `Status` char(1) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_faq`),
  KEY `Categoria_Dep` (`Categoria_Dep`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `faq`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `logfile`
-- 

CREATE TABLE `logfile` (
  `id_log` int(9) NOT NULL auto_increment,
  `data` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `id_user` int(9) default NULL,
  `tabela` varchar(50) collate latin1_general_ci default NULL,
  `operacao` char(1) collate latin1_general_ci default NULL,
  `descricao` text collate latin1_general_ci,
  PRIMARY KEY  (`id_log`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `logfile`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `noticia`
-- 

CREATE TABLE `noticia` (
  `id_noticia` int(9) NOT NULL auto_increment,
  `Data_inicio` date NOT NULL,
  `Data_fim` date NOT NULL,
  `Assunto` varchar(20) collate latin1_general_ci NOT NULL,
  `Noticia` text collate latin1_general_ci NOT NULL,
  `Status` char(1) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_noticia`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `noticia`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `resposta`
-- 

CREATE TABLE `resposta` (
  `id_resposta` int(9) NOT NULL auto_increment,
  `id_user` int(9) default NULL,
  `data` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `Resposta` text collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_resposta`),
  KEY `id_user` (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `resposta`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `resposta_ticket`
-- 

CREATE TABLE `resposta_ticket` (
  `id_resposta` int(9) default NULL,
  `id_ticket` int(9) default NULL,
  KEY `id_resposta` (`id_resposta`),
  KEY `id_ticket` (`id_ticket`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Extraindo dados da tabela `resposta_ticket`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `ticket`
-- 

CREATE TABLE `ticket` (
  `id_ticket` int(9) NOT NULL auto_increment,
  `id_user` int(9) NOT NULL,
  `data` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `tipo_ticket` char(1) collate latin1_general_ci NOT NULL,
  `assunto_local` varchar(50) collate latin1_general_ci NOT NULL,
  `mensagem_sintomas` text collate latin1_general_ci NOT NULL,
  `id_departamento_destino` int(9) NOT NULL,
  `urgencia` tinyint(1) NOT NULL,
  `status` char(1) collate latin1_general_ci NOT NULL,
  `id_user_atribuido` int(9) default NULL,
  `data_atribuido` date default NULL,
  PRIMARY KEY  (`id_ticket`),
  KEY `id_user` (`id_user`),
  KEY `id_departamento_destino` (`id_departamento_destino`),
  KEY `id_user_atribuido` (`id_user_atribuido`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `ticket`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `tipo_user`
-- 

CREATE TABLE `tipo_user` (
  `id_tipoUser` int(9) NOT NULL auto_increment,
  `Nome` varchar(30) collate latin1_general_ci NOT NULL,
  `Permissoes` tinyint(1) NOT NULL,
  `Status` char(1) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_tipoUser`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `tipo_user`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `user`
-- 

CREATE TABLE `user` (
  `id_user` int(9) NOT NULL auto_increment,
  `nome` varchar(50) collate latin1_general_ci NOT NULL,
  `username` varchar(20) collate latin1_general_ci NOT NULL,
  `password` char(40) collate latin1_general_ci NOT NULL,
  `email` varchar(100) collate latin1_general_ci NOT NULL,
  `telefone` int(9) default NULL,
  `id_departamento` varchar(3) collate latin1_general_ci NOT NULL,
  `tipo_user` int(11) default NULL,
  `status` char(1) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`id_user`),
  KEY `id_departamento` (`id_departamento`),
  KEY `tipo_user` (`tipo_user`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

-- 
-- Extraindo dados da tabela `user`
-- 


-- --------------------------------------------------------

-- 
-- Estrutura da tabela `user_departamento`
-- 

CREATE TABLE `user_departamento` (
  `id_user` int(9) default NULL,
  `id_departamento` varchar(3) collate latin1_general_ci default NULL,
  KEY `id_user` (`id_user`),
  KEY `id_departamento` (`id_departamento`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- 
-- Extraindo dados da tabela `user_departamento`
-- 

